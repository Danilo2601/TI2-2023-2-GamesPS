// NOT DONE : SCROLL TO SELECTED
var games = [
    {
        "id": "NONE",
        "name": "NONE",
        "company": "Joe",
        "mainImage": "TROLOLOLOLOLOLOLO.png",
        "subImages": [
            "TROLOLOLOLOLOLOLO.png",
            "TROLOLOLOLOLOLOLO.png",
            "TROLOLOLOLOLOLOLO.png",
            "TROLOLOLOLOLOLOLO.png",
            "TROLOLOLOLOLOLOLO.png",
            "TROLOLOLOLOLOLOLO.png",
            "TROLOLOLOLOLOLOLO.png"
        ],
        "plataform": [
            { "name": "stadia", "price": "R$ 69,96" }
        ],
        "sinopsys": "nah",
        "score": {
            "average": 69,
            "total": 100000,
            "likes": 69000,
            "dislikes": 1
        }
    },
    {
        "id": "totk",
        "name": "Tears Of The Kingdoom",
        "company": "Nintendo",
        "mainImage": "https://assets.nintendo.com/image/upload/w_920,f_auto,q_auto/v1681238674/Microsites/zelda-tears-of-the-kingdom/videos/posters/totk_microsite_officialtrailer3_1304xj47am",
        "subImages": [
            "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.0/c_scale,w_700/ncom/software/switch/70010000063714/ca80e4d9f7ddc2971daea8d9b9144c42dbdf2245c3546f41b94a740067bd42a0",
            "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.0/c_scale,w_700/ncom/software/switch/70010000063714/05b3d8e8c74beaa43a7714c275a7ad06018ed069bd6bd3f923442b9ac16fdc49",
            "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.0/c_scale,w_700/ncom/software/switch/70010000063714/490ccb15d914eabada74b34de895e9061c7917d7f75782bc934a528fb77ea4be",
            "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.0/c_scale,w_700/ncom/software/switch/70010000063714/54e87e1c41d21f32e74c61ad9c18c0a2688800e939d9d5ab97182304b9c37591",
            "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.0/c_scale,w_700/ncom/software/switch/70010000063714/ec907a9568fb27177faf87288e98cee15f4fc4f0ff575ab39b150b3c6efe0350",
            "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.0/c_scale,w_700/ncom/software/switch/70010000063714/1c786a296ab9c1f28ff509723f621311b7525d0c773ae314622b02c03bf27b5b"
        ],
        "plataform": [
            { "name": "switch", "price": "R$ 357,99" }
        ],
        "sinopsys": "The Legend of Zelda: Tears of the Kingdom is a 2023 action-adventure game developed and published by Nintendo for the Nintendo Switch. The sequel to The Legend of Zelda: Breath of the Wild (2017), Tears of the Kingdom retains aspects including the open world environment of Hyrule, which has been expanded to allow for more vertical exploration. Link, the protagonist, joins Princess Zelda to defeat Ganondorf, who seeks to destroy Hyrule. <br>&nbsp&nbspTears of the Kingdom was conceived after ideas for Breath of the Wild downloadable content (DLC) had exceeded its scope. Its development was led by Nintendo's Entertainment Planning & Development (EPD) division, with Breath of the Wild director Hidemaro Fujibayashi and producer Eiji Aonuma reprising their roles. A teaser was shown at E3 2019 with a full reveal at E3 2021. Tears of the Kingdom was initially planned for release in 2022 before being delayed to May 2023. It received acclaim, with praise for its numerous improvements upon its predecessor, expanded open world and features encouraging exploration and experimentation. ",
        "score": {
            "average": 50,
            "total": 2,
            "likes": 1,
            "dislikes": 1
        }
    },
    {
        "id": "rdr2",
        "name": "Red Dead Redemption 2",
        "company": "Rockstar Games",
        "mainImage": "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/header.jpg?t=1671485009",
        "subImages": [
            "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/ss_bac60bacbf5da8945103648c08d27d5e202444ca.1920x1080.jpg?t=1671485009",
            "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/ss_4ce07ae360b166f0f650e9a895a3b4b7bf15e34f.1920x1080.jpg?t=1671485009",
            "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/ss_d1a8f5a69155c3186c65d1da90491fcfd43663d9.1920x1080.jpg?t=1671485009",
            "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/ss_66b553f4c209476d3e4ce25fa4714002cc914c4f.1920x1080.jpg?t=1671485009"
        ],
        "plataform": [
            { "name": "PC", "price": "R$299,90" }
        ],
        "sinopsys": "Red Dead Redemption 2, a épica aventura de mundo aberto da Rockstar Games aclamada pela crítica e o jogo mais bem avaliado desta geração de consoles, agora chega aprimorado para PC com conteúdos inéditos no Modo História, melhorias visuais e muito mais.",
        "score": {
            "average": 50,
            "total": 2,
            "likes": 1,
            "dislikes": 1
        }
    },
    {
        "id": "ttf2",
        "name": "Titanfall 2",
        "company": "EA",
        "mainImage": "https://meups.com.br/wp-content/uploads/2017/04/TitanFall2.jpg",
        "subImages": [
            "https://cdn.akamai.steamstatic.com/steam/apps/1237970/ss_d5c13576c0ab4e6ca93b51aa39aa74271672e75f.600x338.jpg?t=1668565264",
            "https://cdn.akamai.steamstatic.com/steam/apps/1237970/ss_9ed56a85aef47554156999dfbd4091d225da2a47.1920x1080.jpg?t=1668565264",
            "https://cdn.akamai.steamstatic.com/steam/apps/1237970/ss_f4a8464ce43962b76fa6f2156b341eee28ad6494.600x338.jpg?t=1668565264",
            "https://cdn.akamai.steamstatic.com/steam/apps/1237970/ss_9e89b335e17df4e5049ffd30a558ddf50a8e36af.600x338.jpg?t=1668565264",
            "https://cdn.akamai.steamstatic.com/steam/apps/1237970/ss_18550193debe4e3461e9f5daac9eb4e399dcebab.600x338.jpg?t=1668565264",
            "https://store-images.s-microsoft.com/image/apps.13794.68769515955787775.dd469b37-3d66-4efe-b211-0b54bf97b764.be4cf30e-24d3-40c6-aa32-c18dda5bdaae?q=90&w=480&h=270"
        ],
        "plataform": [
            { "name": "Xbox One", "price": "R$ 79,00" }
        ],
        "sinopsys": "Call down your Titan and get ready for an exhilarating first-person shooter experience in Titanfall® 2! The sequel introduces a new single player campaign that explores the bond between Pilot and Titan. Or blast your way through an even more innovative and intense multiplayer experience - featuring 6 new Titans, deadly new Pilot abilities, expanded customization, new maps, modes, and much more.<br><br>KEY FEATURES<br>Experience a captivating single player story. Titanfall® 2 features a single player campaign packed with action and inventive twists. Play as a Militia rifleman stranded behind enemy lines, who encounters a veteran Vanguard-class Titan. The two must work together to uphold a mission they were never meant to carry out.<br>Enjoy multiplayer action that's second to none. The sequel gives players more of the adrenaline-fueled multiplayer combat they've come to expect from the franchise. Take the fast-paced, first-person action to the next level with more Titans, deadlier Pilot abilities, and much more. And be sure to stand out in the middle of all the chaos with new, expanded Pilot, Titan and loadout personalization options! <br><br>Titanfall™ 2 Ultimate Edition Content<br>The best way to jump into one of the most surprising shooters of 2016 is with the Titanfall™ 2 Ultimate Edition.<br>Ultimate Edition includes Titanfall™ 2 base game, Deluxe Edition content (Scorch & Ion Prime Titans, Deluxe Edition Warpaint for 6 Titans, Deluxe Edition Camo for all Titans, Pilots & Weapons, Deluxe Edition Nose Arts for 6 Titans, Deluxe Edition Callsign), and Jump-Starter content (All Titans unlocked, all Pilot tacticals unlocked, 500 credits to unlock loadouts, cosmetics and gear, 10 2x XP tokens, the Underground R-201 Carbine Warpaint).",
        "score": {
            "average": 50,
            "total": 2,
            "likes": 1,
            "dislikes": 1
        }
    }
];


var ID = -1;
let url = window.location.href;
let id = url.substring(url.lastIndexOf('#') + 1);
let C;
for (let i = 0; i < games.length; i++) {
    if (id == games[i].id) {
        ID = i;
        break;
    }
}
var start = (x) => {
    mImage(x);
    sImage(x);
    comp(x);
    score(x);
    plat(x);
    sino(x);
    price(x);
}
var price = (x) => {
    $('#price').text('Price: ' + x.plataform[0].price)
}
var score = (x) => {
    let f = (x.score.likes * 100) / x.score.total;
    x.score.avarage = f;
    let [n, n2] = (((Math.round(f) / 10)).toString()).split('.');
    $('#score').text(n + '.' + (n2 ? n2 : '0'));
}
var plat = (x) => {
    $('#plat #name').text(x.plataform[0].name)
    if (x.plataform.length > 1) {
        document.querySelector('#comp').innerHTML += `<input type="checkbox" id="menuToggle"></input> <nav id="plat"><label for="menuToggle" id="name">${x.plataform[0].name}</label><div id="expand"> </div></nav>`;
        for (let i = 1; i < x.plataform.length; i++) {
            document.querySelector('#expand').innerHTML += `<button id="${i}Button" class="exp">${x.plataform[i].name}</button>`;
        }
    }

}
var comp = (x) => {
    $('#comp #name').text(`${x.company}`);
}
var mImage = (x) => {
    let y = `<div class="carousel-item active"><img src="${x.mainImage}" class="d-block w-100"alt="..." /></div>`;
    let i;
    for (i = 0; i < x.subImages.length; i++) {
        y += `<div class="carousel-item"><img src="${x.subImages[i]}" class="d-block w-100"alt="..." /></div>`;
    }
    document.querySelector('.carousel-inner').innerHTML += y;
}
var sImage = (x) => {
    let y = `<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active 0 previw b S" aria-current="true" aria-label="Slide 1"> <img class="d-block"src="${x.mainImage}"class="img-fluid" />`;
    let i;
    for (i = 0; i < x.subImages.length - 1; i++) {
        y += `<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="${i + 1}" aria-label="Slide ${i + 2}" class="previw ${i + 1} b"> <img class="d-block"src="${x.subImages[i]}"class="img-fluid" />`;
    }
    y += `<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="${i + 1}" aria-label="Slide ${i + 2}" class="previw ${i + 1} b E"> <img class="d-block"src="${x.subImages[i]}"class="img-fluid" />`
    document.querySelector('.carousel-indicators').innerHTML += y;
}
var sino = (x) => {
    document.querySelector('#sinopsys').innerHTML = '&nbsp&nbsp' + x.sinopsys;
}
let GO = () => {
    let [url1, url2] = url.split('#');
    if((games.length > parseFloat($('#debugger').val())) && (parseFloat($('#debugger').val()) >= 0) ){
        window.location.href = (url1 + '#' + games[parseFloat($('#debugger').val())].id);
        location.reload();
    } else {
        $('#debugger').val(ID);
    }
}


onload = () => {
    if (ID == -1) {
        $('#image').css("display", "none");
        ID = 0;
    }

    $('#debugger').val((ID < 1 ? 0 : ID));

    document.querySelector('#debugger').max = games.length - 1;

    $("#debugger").on('keyup', function (e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            GO();
        }
    });

    $('#pag').text(games[ID].name);

    $(":input").bind('keyup change click', function (e) {
        if (!$(this).data("previousValue") || $(this).data("previousValue") != $(this).val()) {

            $('#pag').text(games[$('#debugger').val()].name);

            $(this).data("previousValue", $(this).val());
        }
    });
    $(":input").each(function () {
        $(this).data("previousValue", $(this).val());
    });

    start(games[ID]);
    $('#like').on("click", function () {
        games[ID].score.likes += 1;
        games[ID].score.total += 1;
        score(games[ID]);
    })
    $('#dislike').on("click", function () {
        games[ID].score.dislikes += 1;
        games[ID].score.total += 1;
        score(games[ID]);
    })

    $('.plus').on("click", function () {
        if (parseFloat($('#debugger').val()) < games.length - 1) {
            $("#debugger").val(parseFloat($('#debugger').val()) + 1);
            $('#pag').text(games[parseFloat($('#debugger').val())].name);
            GO();
        }
    });
    $('.minus').on("click", function () {
        if (parseFloat($('#debugger').val()) > 1) {
            $("#debugger").val(parseFloat($('#debugger').val()) - 1);
            $('#pag').text(games[parseFloat($('#debugger').val())].name);
            GO();
        }
    });
}